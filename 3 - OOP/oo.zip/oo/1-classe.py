class Game:
    name = ""
    yearLaunch = 0
    multiplayer = False
    note = 0